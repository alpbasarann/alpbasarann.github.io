import moment from 'moment'
import momentDurationFormatSetup from 'moment-duration-format'
import React from 'react';



momentDurationFormatSetup(moment);

const TimeLeft = ({ 
    handleStartStopClick,  
    startStopButtonLabel, 
    timeLeft, 
    timerLabel,
}) => {
    const formattedTimeLeft = moment.duration(timeLeft, 's').format('mm:ss', {trim: false}); 
    return (
        <div className="flex flex-col justify-evenly items-center w-64 h-64 bg-gray-600 rounded-full">
            <p className="text-gray-900 text-2xl" id="timer-label">{timerLabel}</p>
            <p id="time-left">{formattedTimeLeft}</p>
            <button className="text-indigo-200 font-semibold bg-red-800 px-4 py-2 rounded-lg" id="start_stop" onClick={handleStartStopClick}>{startStopButtonLabel}</button>
        </div>
    );

};

export default TimeLeft;