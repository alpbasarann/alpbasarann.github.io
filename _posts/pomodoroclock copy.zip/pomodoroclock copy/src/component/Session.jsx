import moment from 'moment';
import React from 'react';
import { BreakSessionContainer, BreakSessionLabel, BreakSessionTime, PlusMinusButtonContainer, PlusMinusButton } from '../ui/BreakSessionUi';

const Session = ({sessionLength,
     decrementSessionLengthByOneMinute, 
     incrementSessionLengthByOneMinute,
}) => {
    const sessionLengthInMinutes = moment.duration(sessionLength, 's').minutes()
    return(
        <BreakSessionContainer>
            <BreakSessionLabel id="Session-label">Session</BreakSessionLabel>
            <BreakSessionTime id="Session-length">{sessionLengthInMinutes}</BreakSessionTime>
            <PlusMinusButtonContainer>
                <PlusMinusButton id="Session-decrement" onClick={decrementSessionLengthByOneMinute}>-</PlusMinusButton>
                <PlusMinusButton id="Session-increment" onClick={incrementSessionLengthByOneMinute}>+</PlusMinusButton>
            </PlusMinusButtonContainer>
        </BreakSessionContainer>
    
    )

};
   
  
export default Session;